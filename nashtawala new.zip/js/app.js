// cart

const addToCart = (event) => {
  const button = event.target;
  const item = button.parentElement.parentElement;
  const image = item.getElementsByClassName("item-image")[0].src;
  const name = item.getElementsByClassName("item-name")[0].innerText;
  const price = item.getElementsByClassName("item-price")[0].innerText;
  const id = Math.floor((Math.random() * 100) + 1);
  var cartItems = {
    image,
    name,
    price,
    id
  };


  var existingEntries = JSON.parse(localStorage.getItem("cartItems"));
  if (existingEntries == null) existingEntries = [];

  localStorage.setItem("cartItems", JSON.stringify(cartItems));

  existingEntries.push(cartItems);
  localStorage.setItem("cartItems", JSON.stringify(existingEntries));

  const alert = document.getElementById("alert");

  alert.style.display = "block";

  setTimeout(() => {
    alert.style.display = "none";
  }, 1200)

};

// order_IOgsmlrhpZkO57

const cart = () => {

  
  const cartItems = JSON.parse(localStorage.getItem("cartItems"));
  // <input type="number" oninput="quantity(event)">


  for (let i = 0; i < cartItems.length; i++) {
    const cartDiv = document.getElementById("cart");
    const inp = document.createElement("input");
    const article = document.createElement("article");
    const image = document.createElement("img");
    const div = document.createElement("div");
    const h3 = document.createElement("h3");
    const p = document.createElement("p");
    const id = document.createElement("p");
    const btn = document.createElement("button");
    inp.type = "number";
    inp.className = "cart-item-inp";
    btn.innerText = "Remove";
    btn.style.backgroundColor = "red";
    id.innerText = cartItems[i].id;
    id.className = "item-id";
    id.style.display = "none";

    image.src = cartItems[i].image;

    article.appendChild(image);
    cartDiv.appendChild(article);
    article.appendChild(image);
    article.appendChild(inp);
    article.appendChild(div);
    div.className = "text";
    h3.className = "cart-item-name";
    p.className = "cart-item-price";
    h3.innerText = cartItems[i].name;
    p.innerText = cartItems[i].price;
    div.appendChild(h3);
    div.appendChild(p);
    div.appendChild(btn);
    div.appendChild(id);


    btn.addEventListener("click", (event) => {
      let cartItems = JSON.parse(localStorage.getItem("cartItems"));
      const div = event.target.parentElement.parentElement;
      let stringNVal = div.getElementsByClassName("item-id")[0].innerText;
      let numSeprate = parseInt(stringNVal.match(/\d+/g));
      for (let i = 0; i < cartItems.length; i++) {

        if (cartItems[i].id === numSeprate) {
          cartItems.splice(i, 1);
        }

      }
      cartItems = JSON.stringify(cartItems);
      localStorage.setItem("cartItems", cartItems);
      location.reload();
    });

    

    inp.addEventListener("input", (event) => {
      const itemName = event.target.parentElement.getElementsByClassName("cart-item-name")[0].innerText;
      let itemPrice = event.target.parentElement.getElementsByClassName("cart-item-price")[0];
      const cartItems = JSON.parse(localStorage.getItem("cartItems"));
      const inpVal = event.target.value;
      
      cartItems.forEach(element => {
        if (element.name === itemName) {
          const price = parseInt(element.price.match(/\d+/g));
          console.log(price * inpVal);
          console.log(itemPrice.innerText = `Rs ${price * inpVal}/-`);
          if (inpVal == 0) {
            itemPrice.innerText = element.price;
          }
        }
      });
      for (let i = 0; i < cartItems.length; i++) {
        if(itemName === cartItems[i].name){
        cartItems[i].qunatityPrice = itemPrice.innerText;
        cartItems[i].quantity = inpVal;
      }
      totalAmount()
      }
      localStorage.setItem("cartItems", JSON.stringify(cartItems));
      
    });
  };

 
}

  const totalAmount = () => {
    // Total Amount
    const cartDiv = document.getElementById("cart");
    const prices = cartDiv.getElementsByClassName("cart-item-price");
    // console.log(prices);
    let sum = 0;
    for (let i = 0; i < prices.length; i++) {
      let numSeprate = parseInt(prices[i].innerText.match(/\d+/g))
      sum = sum + numSeprate;
    }
    localStorage.setItem("totalAmount", sum);
    const calculation = document.getElementById("calculation");
    const p = document.getElementById("total-amount-txt");
    p.innerText = `Total Amount - Rs ${localStorage.getItem("totalAmount")}/-`;
    calculation.appendChild(p);
  }

  if (document.URL === "http://127.0.0.1:5500/htmls/cart.html" || "https://nastawala.netlify.app/htmls/cart.html") {
    cart();
    totalAmount();
  }

  // Pay
  function pay (event) {

    event.preventDefault();
    
    const name = document.getElementsByName("name")[0].value;
    const phone = document.getElementsByName("phone")[0].value;
    const address = document.getElementsByName("address")[0].value;
    const email = document.getElementsByName("email")[0].value;
    

    let userDetails = {
      name,
      address,
      phone,
      email
    }

    localStorage.setItem("userDetails", JSON.stringify(userDetails));
    var uDetails = JSON.parse(localStorage.getItem("userDetails"));
    // .match(/\d+/g)
    

    const rzp_options = {
      key: "rzp_test_r5QAleiJm6TxsQ",
      amount: parseInt(localStorage.getItem("totalAmount"))*100,
      name: "{nastaWala}",
      // description: "",
      handler: function (response) {
        // alert(`Payment Succesful ${response.razorpay_payment_id}`)
        const nav = document.getElementById("navbar");
        const paymentAlert = document.getElementById("payment-alert");

        nav.style.display = "none";
        paymentAlert.style.display = "block";

        setTimeout(() => {
          location.reload();
        }, 1200)
      },
      modal: {
        ondismiss: function () {
          alert(`Payment Failed`)
        }
      },
      prefill: {
        email: uDetails.email,
        contact: uDetails.phone
      },
      // notes: {
      //   name: uDetails.name,
      //   item: "HHA",
      // },
      theme: {
        color: "#667eea"
      }
    };
    const rzp1 = new Razorpay(rzp_options);
    rzp1.open();
}

  // login

  /*const user = {
    name: "Chinmay Kulthe",
    address: "42 Street New Delhi",
    phoneNo: 9981141,
  };
  
  localStorage.setItem("user", JSON.stringify(user));
  
  JSON.parse(localStorage.getItem("user"));
  
  console.log(JSON.parse(localStorage.getItem("user"))); */

  // Save Dish
  /*fetch(`http://localhost:3000/save-dish?price=89&description=ip&category=jj`)
    .then((response) => {
      if (response.status === 404) {
        console.log("Error");
      } else {
      }
    })
    .then((data) => console.clear());*/
